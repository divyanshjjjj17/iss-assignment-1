awk '{print $NF, " Once said "; print}' quotes.txt > speech.txt | sed 's/\~.*//' speech.txt
