awk '{print " Line No: " NR "count of words: "NF}' quotes.txt
