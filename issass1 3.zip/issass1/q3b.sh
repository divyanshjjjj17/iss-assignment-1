wc -l quotes.txt
     100 quotes.txt
