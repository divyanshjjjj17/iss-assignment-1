grep -wo '[[:alnum:]]\+' a.txt | sort |uniq -cd
