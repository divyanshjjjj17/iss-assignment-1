wc -w quotes.txt
    1875 quotes.txt
